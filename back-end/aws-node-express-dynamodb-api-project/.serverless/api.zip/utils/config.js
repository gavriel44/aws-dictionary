module.exports = {
  DICTIONARY_TABLE: process.env.DICTIONARY_TABLE || "dictionary-table-dev",
  IS_OFFLINE: process.env.IS_OFFLINE,
};
